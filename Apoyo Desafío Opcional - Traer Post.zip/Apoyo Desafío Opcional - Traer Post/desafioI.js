const url = "https://jsonplaceholder.typicode.com/posts/";

const request = async (url) => {
    const resp = await fetch(url);
    const getresp = await resp.json();
    return getresp;
};

const getPosts = (async () =>{
    return await request(url);
})().then(p => {
    try {
        btn.addEventListener('click',(e) => {
            e.preventDefault();
            p.forEach(element => {
                document.getElementById('post-data').innerHTML += `
                    <ul>
                        <ol><h2>${element.title}</h2>${element.body}</ol>
                    </ul>
                    <br>
                `;
            });
        });
    } catch (Error) {
        console.log(Error);
    }
});